
const $ = id => document.getElementById(id);

const linkList = $("linkList");
const emptyState = $("emptyState");
const addForm = $("addForm");
const settingsPanel = $("settingsPanel");

let websites = [];
let editingIndex = null;
let draggedIndex = null;

let settings = {
  accent: "#4285f4"
};

async function initialize() {
  const data = await chrome.storage.local.get([
    "websites",
    "settings"
  ]);

  websites = data.websites || [];
  settings = data.settings || settings;

  $("accentColor").value = settings.accent;
  applySettings();
  render();
}

async function saveWebsites() {
  await chrome.storage.local.set({ websites });
}

async function saveSettings() {
  await chrome.storage.local.set({ settings });
}

function applySettings() {
  document.documentElement.style.setProperty(
    "--accent",
    settings.accent
  );
}

function render() {
  linkList.replaceChildren();

  emptyState.hidden = websites.length !== 0;
  linkList.hidden = websites.length === 0;

  $("siteCount").textContent =
    `${websites.length} website${websites.length === 1 ? "" : "s"} saved`;

  websites.forEach((website, index) => {
    const item = document.createElement("div");
    item.className = "link-item";
    item.draggable = true;

    const handle = document.createElement("span");
    handle.className = "drag-handle";
    handle.textContent = "⠿";
    handle.title = "Drag to rearrange";

    const icon = document.createElement("img");
    icon.className = "site-icon";

    const hostname = new URL(website.url).hostname;

    icon.src =
      `https://www.google.com/s2/favicons?domain=${encodeURIComponent(hostname)}&sz=64`;

    icon.alt = "";

    icon.onerror = () => {
      const fallback = document.createElement("div");
      fallback.className = "site-icon site-fallback";
      fallback.textContent = website.name.charAt(0).toUpperCase();
      icon.replaceWith(fallback);
    };

    const info = document.createElement("div");
    info.className = "site-info";

    const name = document.createElement("div");
    name.className = "site-name";
    name.textContent = website.name;

    const url = document.createElement("div");
    url.className = "site-url";
    url.textContent = hostname;

    info.append(name, url);

    const edit = document.createElement("button");
    edit.className = "item-action";
    edit.textContent = "✎";
    edit.title = "Edit website";

    edit.addEventListener("click", event => {
      event.stopPropagation();
      showForm(index);
    });

    const remove = document.createElement("button");
    remove.className = "item-action delete-btn";
    remove.textContent = "×";
    remove.title = "Delete website";

    remove.addEventListener("click", async event => {
      event.stopPropagation();

      websites.splice(index, 1);
      await saveWebsites();
      render();
    });

    item.append(handle, icon, info, edit, remove);

    item.addEventListener("click", () => {
      chrome.tabs.create({ url: website.url });
    });

    item.addEventListener("dragstart", event => {
      draggedIndex = index;
      item.classList.add("dragging");
      event.dataTransfer.effectAllowed = "move";
    });

    item.addEventListener("dragend", () => {
      draggedIndex = null;
      document.querySelectorAll(".link-item").forEach(row => {
        row.classList.remove("dragging", "drag-over");
      });
    });

    item.addEventListener("dragover", event => {
      event.preventDefault();
      item.classList.add("drag-over");
    });

    item.addEventListener("dragleave", () => {
      item.classList.remove("drag-over");
    });

    item.addEventListener("drop", async event => {
      event.preventDefault();
      item.classList.remove("drag-over");

      if (draggedIndex === null || draggedIndex === index) return;

      const moved = websites.splice(draggedIndex, 1)[0];
      websites.splice(index, 0, moved);

      await saveWebsites();
      render();
    });

    linkList.appendChild(item);
  });
}

function showForm(index = null) {
  editingIndex = index;

  $("formTitle").textContent =
    index === null ? "Add a website" : "Edit website";

  if (index !== null) {
    $("siteName").value = websites[index].name;
    $("siteUrl").value = websites[index].url;
  } else {
    $("siteName").value = "";
    $("siteUrl").value = "";
  }

  $("errorMessage").textContent = "";

  linkList.hidden = true;
  emptyState.hidden = true;
  settingsPanel.hidden = true;
  addForm.hidden = false;

  $("siteName").focus();
}

function hidePanels() {
  addForm.hidden = true;
  settingsPanel.hidden = true;
  render();
}

$("addBtn").addEventListener("click", () => showForm());
$("emptyAddBtn").addEventListener("click", () => showForm());

$("cancelBtn").addEventListener("click", hidePanels);
$("backBtn").addEventListener("click", hidePanels);

$("settingsBtn").addEventListener("click", () => {
  addForm.hidden = true;
  linkList.hidden = true;
  emptyState.hidden = true;
  settingsPanel.hidden = false;
});

$("accentColor").addEventListener("change", async event => {
  settings.accent = event.target.value;
  applySettings();
  await saveSettings();
});

addForm.addEventListener("submit", async event => {
  event.preventDefault();

  const name = $("siteName").value.trim();
  let url = $("siteUrl").value.trim();

  if (!name || !url) {
    $("errorMessage").textContent = "Please fill in both fields.";
    return;
  }

  if (!/^https?:\/\//i.test(url)) {
    url = "https://" + url;
  }

  let parsed;

  try {
    parsed = new URL(url);
  } catch {
    $("errorMessage").textContent = "Invalid website URL.";
    return;
  }

  if (
    !["http:", "https:"].includes(parsed.protocol) ||
    !parsed.hostname.includes(".") ||
    parsed.hostname.startsWith(".") ||
    parsed.hostname.endsWith(".")
  ) {
    $("errorMessage").textContent = "Please enter a valid website.";
    return;
  }

  url = parsed.href;

  const duplicate = websites.some((website, index) =>
    website.url.toLowerCase() === url.toLowerCase() &&
    index !== editingIndex
  );

  if (duplicate) {
    $("errorMessage").textContent = "This website is already saved.";
    return;
  }

  const newWebsite = { name, url };

  if (editingIndex !== null) {
    websites[editingIndex] = newWebsite;
  } else {
    websites.push(newWebsite);
  }

  await saveWebsites();

  editingIndex = null;
  hidePanels();
});

initialize();
